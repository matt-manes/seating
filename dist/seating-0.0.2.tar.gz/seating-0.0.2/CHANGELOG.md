# Changelog

## v0.0.1 (2023-06-12)

#### Performance improvements

* properties includes cached_properties
* comments and expressions (class doc strings) will be reinserted by index instead of line number

#### Docs

* update readme


